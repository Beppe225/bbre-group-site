<?php
/*
 * Template Name: BBRE Finance
 */
get_header();
?>
<style>

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #2C3E50; }

        nav {
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
            background: rgba(10, 25, 41, 0.95); backdrop-filter: blur(10px);
            padding: 0 40px; height: 70px;
            display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid rgba(201,169,98,0.2);
        }
        .nav-logo { font-family: Georgia, serif; font-size: 1.5rem; font-weight: 900; color: white; text-decoration: none; }
        .nav-logo span { color: #C9A962; }
        .nav-links { display: flex; gap: 30px; list-style: none; }
        .nav-links a { color: rgba(255,255,255,0.8); text-decoration: none; font-size: 0.9rem; font-weight: 500; letter-spacing: 0.5px; transition: color 0.2s; }
        .nav-links a:hover { color: #C9A962; }
        .nav-cta { background: #C9A962; color: white; padding: 10px 24px; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: background 0.2s; }
        .nav-cta:hover { background: #b8934f; }

        .hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 140px 20px 90px; text-align: center;
            position: relative; overflow: hidden;
        }
        .hero::before {
            content: ''; position: absolute; top: -50%; right: -20%;
            width: 80%; height: 150%;
            background: radial-gradient(circle, rgba(201,169,98,0.12) 0%, transparent 70%);
        }
        .hero-inner { position: relative; z-index: 2; max-width: 1000px; margin: 0 auto; }
        .breadcrumb { display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 20px; }
        .breadcrumb a { color: rgba(255,255,255,0.6); text-decoration: none; font-size: 0.85rem; }
        .breadcrumb a:hover { color: #C9A962; }
        .breadcrumb span { color: rgba(255,255,255,0.4); font-size: 0.85rem; }
        .hero-badge {
            display: inline-block; background: rgba(201,169,98,0.15); color: #C9A962;
            border: 1px solid rgba(201,169,98,0.4); padding: 8px 20px; border-radius: 50px;
            font-size: 0.8rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase;
            margin-bottom: 24px;
        }
        .hero h1 { font-family: Georgia, serif; font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; margin-bottom: 20px; line-height: 1.15; }
        .hero h1 span { color: #C9A962; }
        .hero p { font-size: clamp(1rem, 2vw, 1.2rem); max-width: 700px; margin: 0 auto 36px; opacity: 0.88; line-height: 1.85; }
        .hero-btns { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
        .btn-primary { background: #C9A962; color: white; padding: 15px 40px; text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 1rem; transition: all 0.2s; }
        .btn-primary:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.3); }
        .btn-outline { background: transparent; color: white; padding: 15px 40px; text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 1rem; border: 2px solid rgba(255,255,255,0.5); transition: all 0.2s; }
        .btn-outline:hover { border-color: white; background: rgba(255,255,255,0.08); }

        .section { padding: 90px 40px; }
        .section-light { background: white; }
        .section-gray { background: #F4F6F8; }
        .section-dark { background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%); color: white; }
        .section-inner { max-width: 1200px; margin: 0 auto; }
        .section-tag { color: #C9A962; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; font-size: 0.8rem; margin-bottom: 14px; }
        .section-title { font-family: Georgia, serif; font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 900; color: #0A1929; margin-bottom: 18px; line-height: 1.2; }
        .section-dark .section-title { color: white; }
        .section-title span { color: #C9A962; }
        .section-lead { font-size: 1.1rem; color: #5A6C7D; line-height: 1.85; max-width: 700px; margin-bottom: 50px; }
        .section-dark .section-lead { color: rgba(255,255,255,0.8); }

        .products-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; margin-top: 50px; }
        .product-card {
            background: white; border-radius: 12px; padding: 36px;
            box-shadow: 0 2px 14px rgba(0,0,0,0.07); border-top: 3px solid #C9A962;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .product-card:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(0,0,0,0.12); }
        .product-icon { font-size: 2.2rem; margin-bottom: 18px; }
        .product-card h3 { font-family: Georgia, serif; font-size: 1.2rem; font-weight: 700; color: #0A1929; margin-bottom: 12px; }
        .product-card p { color: #5A6C7D; font-size: 0.95rem; line-height: 1.75; margin-bottom: 16px; }
        .product-tags { display: flex; flex-wrap: wrap; gap: 8px; }
        .product-tag { background: #F4F6F8; color: #5A6C7D; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }

        .vantaggi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 24px; margin-top: 50px; }
        .vantaggio { text-align: center; padding: 30px 24px; background: rgba(255,255,255,0.05); border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); }
        .vantaggio-icon { font-size: 2.4rem; margin-bottom: 16px; }
        .vantaggio h4 { font-size: 1rem; font-weight: 700; color: white; margin-bottom: 10px; }
        .vantaggio p { font-size: 0.9rem; color: rgba(255,255,255,0.75); line-height: 1.65; }

        .features-two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 30px; }
        .feature-item { display: flex; align-items: flex-start; gap: 12px; padding: 14px 0; border-bottom: 1px solid #f0f0f0; }
        .feature-item:last-child { border-bottom: none; }
        .feature-check { color: #C9A962; font-weight: 900; font-size: 1.1rem; flex-shrink: 0; margin-top: 1px; }
        .feature-item span { font-size: 0.95rem; color: #2C3E50; line-height: 1.5; }

        .cta-box { background: white; border-radius: 16px; padding: 60px 50px; text-align: center; box-shadow: 0 8px 40px rgba(0,0,0,0.15); max-width: 700px; margin: 0 auto; border-top: 4px solid #C9A962; }
        .cta-box h3 { font-family: Georgia, serif; font-size: 2rem; font-weight: 900; color: #0A1929; margin-bottom: 16px; }
        .cta-box p { color: #5A6C7D; font-size: 1.05rem; margin-bottom: 32px; line-height: 1.75; }
        .btn-calendar { display: inline-flex; align-items: center; gap: 10px; background: #C9A962; color: white; padding: 16px 44px; text-decoration: none; border-radius: 6px; font-weight: 700; font-size: 1.05rem; transition: all 0.2s; }
        .btn-calendar:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.35); }
        .cta-note { margin-top: 14px; font-size: 0.85rem; color: #8A9BAC; }

        footer { background: #0A1929; color: rgba(255,255,255,0.75); padding: 70px 40px 30px; }
        .footer-grid { max-width: 1300px; margin: 0 auto; display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; margin-bottom: 50px; }
        .footer-brand h3 { font-family: Georgia, serif; font-size: 1.8rem; color: white; margin-bottom: 16px; }
        .footer-brand h3 span { color: #C9A962; }
        .footer-brand p { line-height: 1.8; margin-bottom: 20px; }
        .footer-brand address { font-style: normal; line-height: 1.8; font-size: 0.9rem; }
        .footer-col h4 { color: white; font-weight: 700; margin-bottom: 20px; font-size: 1rem; }
        .footer-col ul { list-style: none; padding: 0; }
        .footer-col ul li { margin-bottom: 12px; }
        .footer-col ul li a { color: rgba(255,255,255,0.65); text-decoration: none; font-size: 0.9rem; transition: color 0.2s; }
        .footer-col ul li a:hover { color: #C9A962; }
        .footer-bottom { text-align: center; padding-top: 30px; border-top: 1px solid rgba(255,255,255,0.1); font-size: 0.85rem; color: rgba(255,255,255,0.4); }
        .footer-bottom a { color: rgba(255,255,255,0.4); text-decoration: none; }
        .footer-bottom a:hover { color: #C9A962; }

        @media (max-width: 768px) {
            nav { padding: 0 20px; }
            .nav-links { display: none; }
            .hamburger { display: flex; }
            nav .nav-cta { display: none; }
            .section { padding: 70px 20px; }
            .features-two-col { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: 1fr 1fr; }
            footer { padding: 60px 20px 30px; }
            .cta-box { padding: 40px 24px; }
        }
        @media (max-width: 480px) { .footer-grid { grid-template-columns: 1fr; } }

        /* HAMBURGER */
        .hamburger { display: none; flex-direction: column; gap: 5px; background: none; border: none; cursor: pointer; padding: 4px; }
        .hamburger span { display: block; width: 24px; height: 2px; background: white; border-radius: 2px; transition: all 0.3s; }
        .hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .hamburger.open span:nth-child(2) { opacity: 0; }
        .hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
        .mobile-nav { display: none; position: fixed; top: 70px; left: 0; right: 0; bottom: 0; background: rgba(10, 25, 41, 0.98); z-index: 99; flex-direction: column; align-items: center; justify-content: center; gap: 32px; }
        .mobile-nav.open { display: flex; }
        .mobile-nav a { color: white; text-decoration: none; font-size: 1.5rem; font-weight: 600; letter-spacing: 1px; transition: color 0.2s; }
        .mobile-nav a:hover { color: #C9A962; }
        .back-to-top { position: fixed; bottom: 30px; right: 30px; z-index: 200; width: 48px; height: 48px; background: #C9A962; color: white; border: none; border-radius: 50%; cursor: pointer; font-size: 1.2rem; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 16px rgba(201,169,98,0.4); opacity: 0; pointer-events: none; transition: opacity 0.3s, transform 0.3s; transform: translateY(10px); }
        .back-to-top.visible { opacity: 1; pointer-events: auto; transform: translateY(0); }
        .back-to-top:hover { background: #b8934f; }
        .fade-in { opacity: 0; transform: translateY(30px); transition: opacity 0.6s ease, transform 0.6s ease; }
        .fade-in.visible { opacity: 1; transform: translateY(0); }
        .fade-in-delay-1 { transition-delay: 0.1s; }
        .fade-in-delay-2 { transition-delay: 0.2s; }
    
</style>

<section class="hero">
    <div class="hero-inner">
        <div class="breadcrumb">
            <a href="<?php echo home_url('/'); ?>">BBRE Group</a>
            <span>›</span>
            <span style="color:rgba(255,255,255,0.8);">BBRE Finance</span>
        </div>
        <div class="hero-badge">Divisione Finanziaria</div>
        <h1>Soluzioni Finanziarie<br><span>Personalizzate per Te</span></h1>
        <p>Mutui, leasing, prestiti e finanziamenti su misura per privati, investitori e aziende. Accediamo alle migliori condizioni di mercato grazie a relazioni dirette con oltre 30 istituti di credito.</p>
        <div class="hero-btns">
            <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-primary">Prenota Consulenza Gratuita</a>
            <a href="<?php echo home_url('/'); ?>" class="btn-outline">← Torna alla Home</a>
        </div>
    </div>
</section>

<!-- PRODOTTI -->
<section class="section section-light">
    <div class="section-inner">
        <div class="section-tag">I Nostri Prodotti</div>
        <h2 class="section-title">Soluzioni per ogni<br><span>esigenza finanziaria</span></h2>
        <p class="section-lead">Analizziamo la tua situazione e troviamo il prodotto finanziario più adatto, negoziando le condizioni migliori con le banche partner.</p>
        <div class="products-grid">
            <div class="product-card">
                <div class="product-icon">🏠</div>
                <h3>Mutuo Prima Casa</h3>
                <p>Acquisto della prima abitazione con le migliori condizioni disponibili sul mercato. Accompagnamento completo dalla pre-approvazione al rogito.</p>
                <div class="product-tags">
                    <span class="product-tag">Tasso fisso</span>
                    <span class="product-tag">Tasso variabile</span>
                    <span class="product-tag">Mutuo giovani</span>
                </div>
            </div>
            <div class="product-card">
                <div class="product-icon">📈</div>
                <h3>Mutuo Investimento</h3>
                <p>Finanziamento per acquisto di immobili a reddito, con strutture su misura per ottimizzare il cash flow dell'investimento.</p>
                <div class="product-tags">
                    <span class="product-tag">Buy to let</span>
                    <span class="product-tag">Portafogli</span>
                    <span class="product-tag">Multiproprietà</span>
                </div>
            </div>
            <div class="product-card">
                <div class="product-icon">🔄</div>
                <h3>Surroga e Rinegoziazione</h3>
                <p>Ottimizza il tuo mutuo esistente: surrogazione a condizioni migliori o rinegoziazione con la banca attuale per ridurre la rata mensile.</p>
                <div class="product-tags">
                    <span class="product-tag">Zero costi</span>
                    <span class="product-tag">Risparmio rata</span>
                </div>
            </div>
            <div class="product-card">
                <div class="product-icon">🏢</div>
                <h3>Leasing Immobiliare</h3>
                <p>Soluzione vantaggiosa per l'acquisto di immobili strumentali e commerciali, con benefici fiscali e ottimizzazione del capitale.</p>
                <div class="product-tags">
                    <span class="product-tag">Capannoni</span>
                    <span class="product-tag">Uffici</span>
                    <span class="product-tag">Negozi</span>
                </div>
            </div>
            <div class="product-card">
                <div class="product-icon">💼</div>
                <h3>Finanziamenti Aziendali</h3>
                <p>Credito su misura per imprese: finanziamenti per liquidità, investimenti, espansione operativa e gestione del capitale circolante.</p>
                <div class="product-tags">
                    <span class="product-tag">PMI</span>
                    <span class="product-tag">Startup</span>
                    <span class="product-tag">Professionisti</span>
                </div>
            </div>
            <div class="product-card">
                <div class="product-icon">👤</div>
                <h3>Prestiti Personali</h3>
                <p>Finanziamenti per privati: ristrutturazioni, acquisti importanti, consolidamento debiti. Istruttoria rapida e risposte in 48 ore.</p>
                <div class="product-tags">
                    <span class="product-tag">Cessione del quinto</span>
                    <span class="product-tag">Personale</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- VANTAGGI -->
<section class="section section-dark">
    <div class="section-inner">
        <div class="section-tag">Perché BBRE Finance</div>
        <h2 class="section-title">I nostri <span>vantaggi</span></h2>
        <p class="section-lead">Non siamo una banca: siamo dalla tua parte. Il nostro obiettivo è trovare la soluzione migliore per te, non per l'istituto finanziario.</p>
        <div class="vantaggi-grid">
            <div class="vantaggio">
                <div class="vantaggio-icon">🏦</div>
                <h4>30+ Istituti Partner</h4>
                <p>Accediamo a un'ampia rete di banche e istituti finanziari per trovare le condizioni migliori sul mercato.</p>
            </div>
            <div class="vantaggio">
                <div class="vantaggio-icon">⚡</div>
                <h4>Iter Accelerato</h4>
                <p>Grazie alle relazioni dirette con le banche, otteniamo risposte rapide e agevoliamo l'istruttoria della pratica.</p>
            </div>
            <div class="vantaggio">
                <div class="vantaggio-icon">🎯</div>
                <h4>Consulenza Gratuita</h4>
                <p>L'analisi della tua situazione e la ricerca della soluzione migliore sono completamente gratuite.</p>
            </div>
            <div class="vantaggio">
                <div class="vantaggio-icon">🔗</div>
                <h4>Integrazione di Gruppo</h4>
                <p>Finance, Immobiliare e Opere Edili lavorano insieme per offrirti un'unica soluzione coordinata.</p>
            </div>
        </div>
    </div>
</section>

<!-- PER CHI -->
<section class="section section-gray">
    <div class="section-inner">
        <div class="section-tag">A Chi ci Rivolgiamo</div>
        <h2 class="section-title">Soluzioni per <span>ogni profilo</span></h2>
        <p class="section-lead">Che tu sia un privato, un investitore o un'impresa, BBRE Finance ha la soluzione finanziaria più adatta alla tua situazione.</p>
        <div class="features-two-col">
            <div class="feature-item"><span class="feature-check">✓</span><span>Privati che acquistano la prima o seconda casa</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Investitori immobiliari che cercano leva finanziaria</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Imprenditori con esigenze di liquidità aziendale</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Professionisti con reddito variabile o P.IVA</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Chi vuole surrogare o rinegoziare il mutuo attuale</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Aziende che acquistano immobili strumentali</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Chi ha avuto difficoltà con le banche in passato</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Acquirenti in asta che necessitano di tempi rapidi</span></div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="section section-light">
    <div class="cta-box">
        <h3>Analisi Gratuita della tua Situazione</h3>
        <p>In 30 minuti valutiamo le tue possibilità di finanziamento e ti presentiamo le opzioni disponibili, senza impegno.</p>
        <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-calendar">
            📅 Prenota Subito — È Gratuito
        </a>
        <p class="cta-note">Nessun impegno • 100% gratuita • Risposta entro 24h</p>
    </div>
</section>

<?php get_footer(); ?>
