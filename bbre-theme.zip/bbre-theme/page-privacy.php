<?php
/*
 * Template Name: BBRE Privacy Policy
 */
get_header();
?>
<style>
        .page-hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 120px 20px 60px; text-align: center;
        }
        .page-hero h1 { font-family: Georgia, serif; font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 900; margin-bottom: 12px; }
        .page-hero p { opacity: 0.7; font-size: 0.95rem; }

        .content-wrap { max-width: 860px; margin: 0 auto; padding: 60px 20px 80px; }
        .content-wrap h2 { font-family: Georgia, serif; font-size: 1.4rem; color: #0A1929; margin: 40px 0 14px; border-left: 3px solid #C9A962; padding-left: 14px; }
        .content-wrap h3 { font-size: 1.1rem; color: #0A1929; margin: 24px 0 10px; }
        .content-wrap p { line-height: 1.85; margin-bottom: 14px; color: #444; }
        .content-wrap ul { margin: 10px 0 16px 24px; }
        .content-wrap ul li { line-height: 1.8; color: #444; margin-bottom: 6px; }
        .content-wrap a { color: #C9A962; text-decoration: none; }
        .content-wrap a:hover { text-decoration: underline; }
        .info-box { background: #fff; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px 24px; margin: 20px 0; }
        .info-box strong { display: block; margin-bottom: 6px; color: #0A1929; }
        .last-updated { background: #fff8ee; border: 1px solid rgba(201,169,98,0.3); border-radius: 6px; padding: 12px 18px; margin-bottom: 30px; font-size: 0.9rem; color: #7a6030; }

        footer { background: #0A1929; color: rgba(255,255,255,0.6); text-align: center; padding: 30px 20px; font-size: 0.85rem; }
        footer a { color: #C9A962; text-decoration: none; }
    
</style>

<div class="page-hero">
    <h1>Privacy Policy</h1>
    <p>Informativa sul trattamento dei dati personali</p>
</div>

<div class="content-wrap">
    <p class="last-updated">Ultimo aggiornamento: 24 marzo 2026</p>

    <p>La presente informativa descrive le modalità di trattamento dei dati personali degli utenti che visitano il sito web di BBRE Group SRL, in conformità al Regolamento UE 2016/679 (GDPR) e al D.Lgs. 196/2003 come modificato dal D.Lgs. 101/2018.</p>

    <h2>1. Titolare del Trattamento</h2>
    <div class="info-box">
        <strong>BBRE Group SRL</strong>
        P.IVA: 13621430969<br>
        Sede: Monza (MB), Italia<br>
        Email: <a href="mailto:barbieri@bbre.it">barbieri@bbre.it</a><br>
        Telefono: <a href="tel:+393358083125">+39 335 808 3125</a>
    </div>

    <h2>2. Dati Raccolti</h2>
    <p>Il sito raccoglie le seguenti categorie di dati:</p>
    <h3>Dati di navigazione</h3>
    <p>I sistemi informatici acquisiscono automaticamente alcuni dati la cui trasmissione è implicita nell'uso dei protocolli di comunicazione Internet: indirizzi IP, tipo di browser, sistema operativo, pagine visitate, orari di accesso.</p>
    <h3>Dati forniti volontariamente</h3>
    <p>Tramite la prenotazione di consulenze o contatto diretto, l'utente può fornire: nome, cognome, email, numero di telefono e informazioni relative alla propria richiesta.</p>

    <h2>3. Finalità e Base Giuridica</h2>
    <ul>
        <li><strong>Gestione richieste:</strong> rispondere a richieste di informazioni e prenotazioni consulenza (base: esecuzione di un contratto / misure precontrattuali)</li>
        <li><strong>Navigazione sicura:</strong> garantire il corretto funzionamento del sito (base: legittimo interesse)</li>
        <li><strong>Obblighi di legge:</strong> adempiere obblighi normativi (base: obbligo legale)</li>
        <li><strong>Marketing:</strong> solo previo consenso esplicito dell'utente</li>
    </ul>

    <h2>4. Conservazione dei Dati</h2>
    <p>I dati sono conservati per il tempo strettamente necessario alle finalità per cui sono stati raccolti:</p>
    <ul>
        <li>Dati di navigazione: massimo 12 mesi</li>
        <li>Dati di contatto/consulenza: fino a 10 anni per obblighi fiscali/contabili</li>
        <li>Dati di marketing: fino alla revoca del consenso</li>
    </ul>

    <h2>5. Destinatari dei Dati</h2>
    <p>I dati non vengono venduti a terzi. Possono essere condivisi con:</p>
    <ul>
        <li>Fornitori di servizi tecnici (hosting, email) che agiscono come responsabili del trattamento</li>
        <li>Istituti finanziari partner per l'erogazione di consulenze specifiche (previo consenso)</li>
        <li>Autorità competenti in caso di obblighi di legge</li>
    </ul>

    <h2>6. Diritti dell'Interessato</h2>
    <p>Ai sensi degli artt. 15-22 GDPR, l'utente ha diritto di:</p>
    <ul>
        <li>Accedere ai propri dati personali</li>
        <li>Rettificare dati inesatti o incompleti</li>
        <li>Richiedere la cancellazione ("diritto all'oblio")</li>
        <li>Opporsi al trattamento per finalità di marketing</li>
        <li>Richiedere la limitazione del trattamento</li>
        <li>Ricevere i propri dati in formato portabile</li>
        <li>Revocare il consenso in qualsiasi momento</li>
    </ul>
    <p>Per esercitare questi diritti, contattaci a: <a href="mailto:barbieri@bbre.it">barbieri@bbre.it</a></p>
    <p>Hai anche il diritto di presentare reclamo al Garante per la Protezione dei Dati Personali (<a href="https://www.garanteprivacy.it" target="_blank" rel="noopener">www.garanteprivacy.it</a>).</p>

    <h2>7. Cookie</h2>
    <p>Il sito utilizza cookie tecnici necessari al funzionamento e cookie analitici (previa accettazione). Per i dettagli consulta la nostra <a href="<?php echo home_url('/cookie-policy/'); ?>">Cookie Policy</a>.</p>

    <h2>8. Trasferimento Dati Extra-UE</h2>
    <p>I dati non vengono trasferiti al di fuori dello Spazio Economico Europeo. Eventuali trasferimenti futuri avverranno solo nel rispetto del GDPR e con le appropriate garanzie.</p>

    <h2>9. Modifiche alla Privacy Policy</h2>
    <p>Ci riserviamo il diritto di aggiornare questa informativa. Le modifiche saranno pubblicate su questa pagina con indicazione della data di aggiornamento.</p>
</div>

<?php get_footer(); ?>
