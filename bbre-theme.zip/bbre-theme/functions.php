<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function bbre_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );

    register_nav_menus( [
        'primary' => __( 'Menu Principale', 'bbre-group' ),
    ] );
}
add_action( 'after_setup_theme', 'bbre_setup' );

function bbre_enqueue_assets() {
    wp_enqueue_style( 'bbre-style', get_stylesheet_uri(), [], '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'bbre_enqueue_assets' );

// Rimuove il padding-top iniettato da WordPress per la toolbar admin
function bbre_fix_admin_bar() {
    if ( is_admin_bar_showing() ) {
        echo '<style>body { margin-top: 32px !important; } .bbre-nav { top: 32px !important; } @media screen and (max-width:782px){ body { margin-top: 46px !important; } .bbre-nav { top: 46px !important; } }</style>';
    }
}
add_action( 'wp_head', 'bbre_fix_admin_bar' );
