<footer class="bbre-footer">
    <div class="footer-grid">
        <div class="footer-brand">
            <div class="logo">BBRE <span>Group</span></div>
            <p>Il partner strategico per investimenti immobiliari, soluzioni finanziarie e costruzioni chiavi in mano. Milano e provincia.</p>
        </div>
        <div class="footer-col">
            <h4>Divisioni</h4>
            <ul>
                <li><a href="<?php echo home_url('/immobiliare/'); ?>">BBRE Immobiliare</a></li>
                <li><a href="<?php echo home_url('/finance/'); ?>">BBRE Finance</a></li>
                <li><a href="<?php echo home_url('/opere-edili/'); ?>">BBRE Opere Edili</a></li>
                <li><a href="<?php echo home_url('/consulenza-credito/'); ?>">Consulenza Credito</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Servizi</h4>
            <ul>
                <li><span>Investimenti Immobiliari</span></li>
                <li><span>Mutui e Finanziamenti</span></li>
                <li><span>Ristrutturazioni</span></li>
                <li><span>Gestione Patrimoni</span></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Contatti</h4>
            <ul>
                <li><a href="mailto:barbieri@bbre.it">barbieri@bbre.it</a></li>
                <li><a href="tel:+393358083125">+39 335 808 3125</a></li>
                <li><a href="https://www.linkedin.com/company/bbre-group" target="_blank" rel="noopener">LinkedIn</a></li>
                <li><a href="https://www.instagram.com/bbre.group" target="_blank" rel="noopener">Instagram</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> BBRE Group SRL — P.IVA 13621430969 &nbsp;|&nbsp; <a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a> &nbsp;|&nbsp; <a href="<?php echo home_url('/cookie-policy/'); ?>">Cookie Policy</a></p>
    </div>
</footer>

<!-- BACK TO TOP -->
<button class="back-to-top" id="backToTop" aria-label="Torna su" onclick="window.scrollTo({top:0,behavior:'smooth'})">↑</button>

<!-- COOKIE BANNER -->
<div id="cookieBanner">
    <p>Utilizziamo cookie tecnici necessari e, previo consenso, cookie analitici per migliorare la tua esperienza. Leggi la nostra <a href="<?php echo home_url('/cookie-policy/'); ?>">Cookie Policy</a>.</p>
    <div class="cookie-btns">
        <button class="cookie-btn-necessary" onclick="acceptCookies('necessary')">Solo necessari</button>
        <button class="cookie-btn-accept" onclick="acceptCookies('all')">Accetta tutti</button>
    </div>
</div>

<script>
(function() {
    // Navbar scroll
    var nav = document.getElementById('bbrenav');
    window.addEventListener('scroll', function() {
        nav.classList.toggle('scrolled', window.scrollY > 50);
    }, { passive: true });

    // Back to top
    var btt = document.getElementById('backToTop');
    window.addEventListener('scroll', function() {
        btt.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });

    // Hamburger
    var hamburger = document.getElementById('hamburger');
    var mobileNav = document.getElementById('mobileNav');
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('open');
        mobileNav.classList.toggle('open');
        document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
    window.closeMobileNav = function() {
        hamburger.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = '';
    };

    // Scroll animations
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(e) {
            if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }
        });
    }, { threshold: 0.12 });
    document.querySelectorAll('.fade-in').forEach(function(el) { observer.observe(el); });

    // Cookie banner
    if (!localStorage.getItem('bbre_cookie_consent')) {
        var banner = document.getElementById('cookieBanner');
        if (banner) banner.style.display = 'flex';
    }
    window.acceptCookies = function(type) {
        localStorage.setItem('bbre_cookie_consent', type);
        var banner = document.getElementById('cookieBanner');
        if (banner) banner.style.display = 'none';
    };
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
