<?php
/*
 * Template Name: BBRE Cookie Policy
 */
get_header();
?>
<style>
        .page-hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 120px 20px 60px; text-align: center;
        }
        .page-hero h1 { font-family: Georgia, serif; font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 900; margin-bottom: 12px; }
        .page-hero p { opacity: 0.7; font-size: 0.95rem; }

        .content-wrap { max-width: 860px; margin: 0 auto; padding: 60px 20px 80px; }
        .content-wrap h2 { font-family: Georgia, serif; font-size: 1.4rem; color: #0A1929; margin: 40px 0 14px; border-left: 3px solid #C9A962; padding-left: 14px; }
        .content-wrap p { line-height: 1.85; margin-bottom: 14px; color: #444; }
        .content-wrap ul { margin: 10px 0 16px 24px; }
        .content-wrap ul li { line-height: 1.8; color: #444; margin-bottom: 6px; }
        .content-wrap a { color: #C9A962; text-decoration: none; }
        .content-wrap a:hover { text-decoration: underline; }
        .last-updated { background: #fff8ee; border: 1px solid rgba(201,169,98,0.3); border-radius: 6px; padding: 12px 18px; margin-bottom: 30px; font-size: 0.9rem; color: #7a6030; }

        table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 0.9rem; }
        th { background: #0A1929; color: white; padding: 12px 14px; text-align: left; }
        td { padding: 11px 14px; border-bottom: 1px solid #e8e8e8; color: #444; }
        tr:nth-child(even) td { background: #f8f8f8; }

        footer { background: #0A1929; color: rgba(255,255,255,0.6); text-align: center; padding: 30px 20px; font-size: 0.85rem; }
        footer a { color: #C9A962; text-decoration: none; }
    
</style>

<div class="page-hero">
    <h1>Cookie Policy</h1>
    <p>Informazioni sui cookie utilizzati da questo sito</p>
</div>

<div class="content-wrap">
    <p class="last-updated">Ultimo aggiornamento: 24 marzo 2026</p>

    <p>Questa Cookie Policy spiega cosa sono i cookie, come li utilizziamo e come puoi gestirli. Per maggiori informazioni sul trattamento dei dati personali, consulta la nostra <a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a>.</p>

    <h2>1. Cosa sono i Cookie</h2>
    <p>I cookie sono piccoli file di testo che i siti web salvano sul tuo dispositivo quando li visiti. Permettono al sito di ricordare le tue preferenze e di funzionare correttamente. Esistono cookie di prima parte (impostati direttamente dal sito) e di terza parte (impostati da servizi esterni).</p>

    <h2>2. Cookie che Utilizziamo</h2>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Tipo</th>
                <th>Finalità</th>
                <th>Durata</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>bbre_cookie_consent</td>
                <td>Tecnico / Prima parte</td>
                <td>Salva la tua scelta relativa ai cookie</td>
                <td>12 mesi</td>
            </tr>
            <tr>
                <td>_ga, _ga_*</td>
                <td>Analitico / Terza parte (Google)</td>
                <td>Analisi del traffico del sito (anonimizzato)</td>
                <td>2 anni</td>
            </tr>
            <tr>
                <td>_gid</td>
                <td>Analitico / Terza parte (Google)</td>
                <td>Distingue gli utenti per analisi statistiche</td>
                <td>24 ore</td>
            </tr>
        </tbody>
    </table>

    <h2>3. Cookie Tecnici (Necessari)</h2>
    <p>I cookie tecnici sono indispensabili per il corretto funzionamento del sito e non richiedono il tuo consenso. Includono i cookie che ricordano le tue preferenze di navigazione (es. preferenze sui cookie stessi) e quelli necessari alla sicurezza.</p>

    <h2>4. Cookie Analitici</h2>
    <p>Utilizziamo Google Analytics in forma anonimizzata per comprendere come gli utenti interagiscono con il sito (pagine visitate, durata della sessione, ecc.). Questi cookie vengono attivati solo dopo il tuo consenso.</p>
    <p>Puoi disabilitare il tracciamento di Google Analytics installando il componente aggiuntivo: <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener">Google Analytics Opt-out</a>.</p>

    <h2>5. Come Gestire i Cookie</h2>
    <p>Puoi gestire le tue preferenze sui cookie in qualsiasi momento:</p>
    <ul>
        <li><strong>Banner cookie:</strong> clicca su "Impostazioni cookie" nel banner che appare alla prima visita</li>
        <li><strong>Browser:</strong> le impostazioni del tuo browser ti permettono di bloccare o eliminare i cookie. Tieni presente che disabilitare i cookie tecnici potrebbe compromettere il funzionamento del sito.</li>
    </ul>
    <p>Istruzioni per i principali browser:</p>
    <ul>
        <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener">Google Chrome</a></li>
        <li><a href="https://support.mozilla.org/it/kb/protezione-antitracciamento-avanzata-firefox" target="_blank" rel="noopener">Mozilla Firefox</a></li>
        <li><a href="https://support.apple.com/it-it/guide/safari/sfri11471/mac" target="_blank" rel="noopener">Apple Safari</a></li>
        <li><a href="https://support.microsoft.com/it-it/microsoft-edge/eliminare-i-cookie-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" target="_blank" rel="noopener">Microsoft Edge</a></li>
    </ul>

    <h2>6. Aggiornamenti</h2>
    <p>Ci riserviamo il diritto di aggiornare questa Cookie Policy. Le modifiche saranno pubblicate su questa pagina con la data di aggiornamento.</p>

    <h2>7. Contatti</h2>
    <p>Per qualsiasi domanda sui cookie o sul trattamento dei dati: <a href="mailto:barbieri@bbre.it">barbieri@bbre.it</a></p>
</div>

<?php get_footer(); ?>
