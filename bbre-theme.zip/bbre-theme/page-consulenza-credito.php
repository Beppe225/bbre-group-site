<?php
/*
 * Template Name: BBRE Consulenza Credito
 */
get_header();
?>
<style>

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #2C3E50; }

        nav {
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
            background: rgba(10, 25, 41, 0.95); backdrop-filter: blur(10px);
            padding: 0 40px; height: 70px;
            display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid rgba(201,169,98,0.2);
        }
        .nav-logo { font-family: Georgia, serif; font-size: 1.5rem; font-weight: 900; color: white; text-decoration: none; }
        .nav-logo span { color: #C9A962; }
        .nav-links { display: flex; gap: 30px; list-style: none; }
        .nav-links a { color: rgba(255,255,255,0.8); text-decoration: none; font-size: 0.9rem; font-weight: 500; letter-spacing: 0.5px; transition: color 0.2s; }
        .nav-links a:hover { color: #C9A962; }
        .nav-cta { background: #C9A962; color: white; padding: 10px 24px; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: background 0.2s; }
        .nav-cta:hover { background: #b8934f; }

        .hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 140px 20px 90px; text-align: center;
            position: relative; overflow: hidden;
        }
        .hero::before {
            content: ''; position: absolute; top: -50%; right: -20%;
            width: 80%; height: 150%;
            background: radial-gradient(circle, rgba(201,169,98,0.12) 0%, transparent 70%);
        }
        .hero-inner { position: relative; z-index: 2; max-width: 1000px; margin: 0 auto; }
        .breadcrumb { display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 20px; }
        .breadcrumb a { color: rgba(255,255,255,0.6); text-decoration: none; font-size: 0.85rem; }
        .breadcrumb a:hover { color: #C9A962; }
        .breadcrumb span { color: rgba(255,255,255,0.4); font-size: 0.85rem; }
        .hero-badge { display: inline-block; background: rgba(201,169,98,0.15); color: #C9A962; border: 1px solid rgba(201,169,98,0.4); padding: 8px 20px; border-radius: 50px; font-size: 0.8rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 24px; }
        .hero h1 { font-family: Georgia, serif; font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; margin-bottom: 20px; line-height: 1.15; }
        .hero h1 span { color: #C9A962; }
        .hero p { font-size: clamp(1rem, 2vw, 1.2rem); max-width: 700px; margin: 0 auto 36px; opacity: 0.88; line-height: 1.85; }
        .hero-btns { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
        .btn-primary { background: #C9A962; color: white; padding: 15px 40px; text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 1rem; transition: all 0.2s; }
        .btn-primary:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.3); }
        .btn-outline { background: transparent; color: white; padding: 15px 40px; text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 1rem; border: 2px solid rgba(255,255,255,0.5); transition: all 0.2s; }
        .btn-outline:hover { border-color: white; background: rgba(255,255,255,0.08); }

        .section { padding: 90px 40px; }
        .section-light { background: white; }
        .section-gray { background: #F4F6F8; }
        .section-dark { background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%); color: white; }
        .section-inner { max-width: 1200px; margin: 0 auto; }
        .section-tag { color: #C9A962; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; font-size: 0.8rem; margin-bottom: 14px; }
        .section-title { font-family: Georgia, serif; font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 900; color: #0A1929; margin-bottom: 18px; line-height: 1.2; }
        .section-dark .section-title { color: white; }
        .section-title span { color: #C9A962; }
        .section-lead { font-size: 1.1rem; color: #5A6C7D; line-height: 1.85; max-width: 700px; margin-bottom: 50px; }
        .section-dark .section-lead { color: rgba(255,255,255,0.8); }

        .services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; margin-top: 50px; }
        .service-card { background: white; border-radius: 12px; padding: 36px; box-shadow: 0 2px 14px rgba(0,0,0,0.07); border-top: 3px solid #C9A962; transition: transform 0.2s, box-shadow 0.2s; }
        .service-card:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(0,0,0,0.12); }
        .service-icon { font-size: 2.2rem; margin-bottom: 18px; }
        .service-card h3 { font-family: Georgia, serif; font-size: 1.2rem; font-weight: 700; color: #0A1929; margin-bottom: 12px; }
        .service-card p { color: #5A6C7D; font-size: 0.95rem; line-height: 1.75; }

        .casi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px; }
        .caso { padding: 30px; background: rgba(255,255,255,0.05); border-radius: 10px; border: 1px solid rgba(255,255,255,0.1); }
        .caso-label { color: #C9A962; font-size: 0.8rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 14px; }
        .caso h4 { font-size: 1.05rem; font-weight: 700; color: white; margin-bottom: 12px; }
        .caso p { font-size: 0.9rem; color: rgba(255,255,255,0.75); line-height: 1.7; }

        .features-two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 30px; }
        .feature-item { display: flex; align-items: flex-start; gap: 12px; padding: 14px 0; border-bottom: 1px solid #f0f0f0; }
        .feature-item:last-child { border-bottom: none; }
        .feature-check { color: #C9A962; font-weight: 900; font-size: 1.1rem; flex-shrink: 0; margin-top: 1px; }
        .feature-item span { font-size: 0.95rem; color: #2C3E50; line-height: 1.5; }

        .cta-box { background: white; border-radius: 16px; padding: 60px 50px; text-align: center; box-shadow: 0 8px 40px rgba(0,0,0,0.15); max-width: 700px; margin: 0 auto; border-top: 4px solid #C9A962; }
        .cta-box h3 { font-family: Georgia, serif; font-size: 2rem; font-weight: 900; color: #0A1929; margin-bottom: 16px; }
        .cta-box p { color: #5A6C7D; font-size: 1.05rem; margin-bottom: 32px; line-height: 1.75; }
        .btn-calendar { display: inline-flex; align-items: center; gap: 10px; background: #C9A962; color: white; padding: 16px 44px; text-decoration: none; border-radius: 6px; font-weight: 700; font-size: 1.05rem; transition: all 0.2s; }
        .btn-calendar:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.35); }
        .cta-note { margin-top: 14px; font-size: 0.85rem; color: #8A9BAC; }

        footer { background: #0A1929; color: rgba(255,255,255,0.75); padding: 70px 40px 30px; }
        .footer-grid { max-width: 1300px; margin: 0 auto; display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; margin-bottom: 50px; }
        .footer-brand h3 { font-family: Georgia, serif; font-size: 1.8rem; color: white; margin-bottom: 16px; }
        .footer-brand h3 span { color: #C9A962; }
        .footer-brand p { line-height: 1.8; margin-bottom: 20px; }
        .footer-brand address { font-style: normal; line-height: 1.8; font-size: 0.9rem; }
        .footer-col h4 { color: white; font-weight: 700; margin-bottom: 20px; font-size: 1rem; }
        .footer-col ul { list-style: none; padding: 0; }
        .footer-col ul li { margin-bottom: 12px; }
        .footer-col ul li a { color: rgba(255,255,255,0.65); text-decoration: none; font-size: 0.9rem; transition: color 0.2s; }
        .footer-col ul li a:hover { color: #C9A962; }
        .footer-bottom { text-align: center; padding-top: 30px; border-top: 1px solid rgba(255,255,255,0.1); font-size: 0.85rem; color: rgba(255,255,255,0.4); }
        .footer-bottom a { color: rgba(255,255,255,0.4); text-decoration: none; }
        .footer-bottom a:hover { color: #C9A962; }

        @media (max-width: 768px) {
            nav { padding: 0 20px; }
            .nav-links { display: none; }
            .hamburger { display: flex; }
            nav .nav-cta { display: none; }
            .section { padding: 70px 20px; }
            .features-two-col { grid-template-columns: 1fr; }
            .footer-grid { grid-template-columns: 1fr 1fr; }
            footer { padding: 60px 20px 30px; }
            .cta-box { padding: 40px 24px; }
        }
        @media (max-width: 480px) { .footer-grid { grid-template-columns: 1fr; } }

        /* HAMBURGER */
        .hamburger { display: none; flex-direction: column; gap: 5px; background: none; border: none; cursor: pointer; padding: 4px; }
        .hamburger span { display: block; width: 24px; height: 2px; background: white; border-radius: 2px; transition: all 0.3s; }
        .hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .hamburger.open span:nth-child(2) { opacity: 0; }
        .hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
        .mobile-nav { display: none; position: fixed; top: 70px; left: 0; right: 0; bottom: 0; background: rgba(10, 25, 41, 0.98); z-index: 99; flex-direction: column; align-items: center; justify-content: center; gap: 32px; }
        .mobile-nav.open { display: flex; }
        .mobile-nav a { color: white; text-decoration: none; font-size: 1.5rem; font-weight: 600; letter-spacing: 1px; transition: color 0.2s; }
        .mobile-nav a:hover { color: #C9A962; }
        .back-to-top { position: fixed; bottom: 30px; right: 30px; z-index: 200; width: 48px; height: 48px; background: #C9A962; color: white; border: none; border-radius: 50%; cursor: pointer; font-size: 1.2rem; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 16px rgba(201,169,98,0.4); opacity: 0; pointer-events: none; transition: opacity 0.3s, transform 0.3s; transform: translateY(10px); }
        .back-to-top.visible { opacity: 1; pointer-events: auto; transform: translateY(0); }
        .back-to-top:hover { background: #b8934f; }
        .fade-in { opacity: 0; transform: translateY(30px); transition: opacity 0.6s ease, transform 0.6s ease; }
        .fade-in.visible { opacity: 1; transform: translateY(0); }
        .fade-in-delay-1 { transition-delay: 0.1s; }
        .fade-in-delay-2 { transition-delay: 0.2s; }
    
</style>

<section class="hero">
    <div class="hero-inner">
        <div class="breadcrumb">
            <a href="<?php echo home_url('/'); ?>">BBRE Group</a>
            <span>›</span>
            <span style="color:rgba(255,255,255,0.8);">BBRE Consulenza Credito</span>
        </div>
        <div class="hero-badge">Divisione Credito e Patrimonio</div>
        <h1>Gestione Credito e<br><span>Pianificazione Patrimoniale</span></h1>
        <p>Analisi, ristrutturazione e ottimizzazione della posizione creditizia per privati e aziende. Pianificazione patrimoniale e fiscale integrata con la strategia immobiliare.</p>
        <div class="hero-btns">
            <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-primary">Prenota Consulenza Gratuita</a>
            <a href="<?php echo home_url('/'); ?>" class="btn-outline">← Torna alla Home</a>
        </div>
    </div>
</section>

<!-- SERVIZI -->
<section class="section section-light">
    <div class="section-inner">
        <div class="section-tag">I Nostri Servizi</div>
        <h2 class="section-title">Gestione integrata del<br><span>credito e del patrimonio</span></h2>
        <p class="section-lead">Dall'analisi della centrale rischi alla pianificazione fiscale: un supporto completo per ottimizzare la tua posizione finanziaria e patrimoniale.</p>
        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon">🔍</div>
                <h3>Analisi del Credito</h3>
                <p>Verifica della posizione in Centrale Rischi, analisi degli sconfinamenti, dei crediti deteriorati e delle segnalazioni. Piano di ripristino della bancabilità.</p>
            </div>
            <div class="service-card">
                <div class="service-icon">🔄</div>
                <h3>Ristrutturazione del Debito</h3>
                <p>Negoziazione con gli istituti creditori per riscadenziamento, consolidamento e riduzione del debito. Accordi stragiudiziali e soluzioni transattive.</p>
            </div>
            <div class="service-card">
                <div class="service-icon">📊</div>
                <h3>Pianificazione Patrimoniale</h3>
                <p>Analisi del patrimonio complessivo, protezione dei beni, pianificazione del passaggio generazionale e ottimizzazione della struttura proprietaria.</p>
            </div>
            <div class="service-card">
                <div class="service-icon">🏛️</div>
                <h3>Ottimizzazione Fiscale Immobiliare</h3>
                <p>Strutturazione fiscale delle operazioni immobiliari: scelta della forma giuridica, regime IVA, imposte di registro e pianificazione delle plusvalenze.</p>
            </div>
            <div class="service-card">
                <div class="service-icon">🤝</div>
                <h3>Consulenza Creditizia Strategica</h3>
                <p>Accompagnamento nella relazione con le banche: presentazione della pratica, supporto nelle fasi di istruttoria, gestione del rating creditizio.</p>
            </div>
            <div class="service-card">
                <div class="service-icon">📋</div>
                <h3>Business Plan Immobiliare</h3>
                <p>Redazione di business plan per operazioni immobiliari complesse, con analisi finanziaria, proiezioni di cash flow e presentazione alle banche.</p>
            </div>
        </div>
    </div>
</section>

<!-- CASI D'USO -->
<section class="section section-dark">
    <div class="section-inner">
        <div class="section-tag">Chi Aiutiamo</div>
        <h2 class="section-title">Casi <span>concreti</span></h2>
        <p class="section-lead">BBRE Consulenza Credito interviene in situazioni diverse, sempre con l'obiettivo di ripristinare o ottimizzare la posizione finanziaria del cliente.</p>
        <div class="casi-grid" style="margin-top: 50px;">
            <div class="caso">
                <div class="caso-label">Caso 1</div>
                <h4>Imprenditore con Debiti Bancari</h4>
                <p>Analisi della posizione, negoziazione con le banche per un piano di rientro sostenibile e ristrutturazione del debito per evitare procedure esecutive.</p>
            </div>
            <div class="caso">
                <div class="caso-label">Caso 2</div>
                <h4>Privato Segnalato in CRIF</h4>
                <p>Verifica delle segnalazioni negative, contestazione di quelle illegittime, piano di ripristino della bancabilità per accedere nuovamente al credito.</p>
            </div>
            <div class="caso">
                <div class="caso-label">Caso 3</div>
                <h4>Investitore con Portafoglio Immobiliare</h4>
                <p>Ottimizzazione della struttura societaria, pianificazione fiscale delle plusvalenze, gestione efficiente del patrimonio immobiliare.</p>
            </div>
            <div class="caso">
                <div class="caso-label">Caso 4</div>
                <h4>Azienda in Difficoltà Finanziaria</h4>
                <p>Analisi della situazione creditizia aziendale, ristrutturazione del debito, accesso a strumenti agevolativi e supporto nelle trattative con i creditori.</p>
            </div>
        </div>
    </div>
</section>

<!-- PERCHÉ NOI -->
<section class="section section-gray">
    <div class="section-inner">
        <div class="section-tag">I Nostri Punti di Forza</div>
        <h2 class="section-title">Perché scegliere <span>BBRE Consulenza Credito</span></h2>
        <p class="section-lead">Esperienza, reti professionali e integrazione con le altre divisioni BBRE: la soluzione globale per ogni esigenza creditizia e patrimoniale.</p>
        <div class="features-two-col">
            <div class="feature-item"><span class="feature-check">✓</span><span>Analisi gratuita della posizione creditizia iniziale</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Team di commercialisti e consulenti creditizi esperti</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Relazioni consolidate con istituti bancari e servicer</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Integrazione con BBRE Finance per soluzioni complete</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Pianificazione fiscale integrata con le operazioni immobiliari</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Supporto nelle procedure di composizione della crisi</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Approccio riservato e professionale in ogni situazione</span></div>
            <div class="feature-item"><span class="feature-check">✓</span><span>Monitoraggio continuo della posizione nel tempo</span></div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="section section-light">
    <div class="cta-box">
        <h3>Analisi Gratuita della tua Posizione</h3>
        <p>Raccontaci la tua situazione. In 30 minuti analizziamo la posizione creditizia e patrimoniale e ti illustriamo le soluzioni disponibili.</p>
        <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-calendar">
            📅 Prenota Consulenza Gratuita
        </a>
        <p class="cta-note">Nessun impegno • 100% gratuita • Massima riservatezza</p>
    </div>
</section>

<?php get_footer(); ?>
