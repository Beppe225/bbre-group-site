<?php
/*
 * Template Name: BBRE Homepage
 */
get_header();
?>
<style>

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #2C3E50; }

        /* NAV */
        nav {
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
            background: rgba(10, 25, 41, 0.95); backdrop-filter: blur(10px);
            padding: 0 40px; height: 70px;
            display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid rgba(201,169,98,0.2);
        }
        .nav-logo { font-family: Georgia, serif; font-size: 1.5rem; font-weight: 900; color: white; text-decoration: none; }
        .nav-logo span { color: #C9A962; }
        .nav-links { display: flex; gap: 30px; list-style: none; }
        .nav-links a { color: rgba(255,255,255,0.8); text-decoration: none; font-size: 0.9rem; font-weight: 500; letter-spacing: 0.5px; transition: color 0.2s; }
        .nav-links a:hover { color: #C9A962; }
        .nav-cta { background: #C9A962; color: white; padding: 10px 24px; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: background 0.2s; }
        .nav-cta:hover { background: #b8934f; }

        /* HERO */
        .hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 160px 20px 100px; text-align: center;
            position: relative; overflow: hidden; min-height: 100vh;
            display: flex; align-items: center;
        }
        .hero::before {
            content: ''; position: absolute; top: -50%; right: -20%;
            width: 80%; height: 150%;
            background: radial-gradient(circle, rgba(201,169,98,0.12) 0%, transparent 70%);
        }
        .hero::after {
            content: ''; position: absolute; bottom: -30%; left: -10%;
            width: 60%; height: 100%;
            background: radial-gradient(circle, rgba(201,169,98,0.06) 0%, transparent 70%);
        }
        .hero-inner { position: relative; z-index: 2; max-width: 1100px; margin: 0 auto; width: 100%; }
        .hero-badge {
            display: inline-block; background: rgba(201,169,98,0.15); color: #C9A962;
            border: 1px solid rgba(201,169,98,0.4); padding: 8px 20px; border-radius: 50px;
            font-size: 0.8rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase;
            margin-bottom: 30px;
        }
        .hero h1 {
            font-family: Georgia, serif; font-size: clamp(2.2rem, 5vw, 4rem);
            font-weight: 900; margin-bottom: 25px; line-height: 1.1;
        }
        .hero h1 span { color: #C9A962; display: block; margin-top: 8px; }
        .hero p {
            font-size: clamp(1rem, 2vw, 1.25rem); margin: 0 auto 40px;
            max-width: 750px; opacity: 0.88; line-height: 1.85;
        }
        .hero-btns { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-bottom: 70px; }
        .btn-primary {
            background: #C9A962; color: white; padding: 16px 44px;
            text-decoration: none; border-radius: 4px; font-weight: 700;
            font-size: 1rem; transition: all 0.2s; display: inline-block;
        }
        .btn-primary:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.3); }
        .btn-outline {
            background: transparent; color: white; padding: 16px 44px;
            text-decoration: none; border-radius: 4px; font-weight: 700;
            font-size: 1rem; border: 2px solid rgba(255,255,255,0.5);
            transition: all 0.2s; display: inline-block;
        }
        .btn-outline:hover { border-color: white; background: rgba(255,255,255,0.08); }
        .hero-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; max-width: 700px; margin: 0 auto; }
        .stat-card {
            background: rgba(255,255,255,0.05); padding: 30px 20px;
            border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
        }
        .stat-card .num {
            font-family: Georgia, serif; font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 900; color: #C9A962; margin-bottom: 8px;
        }
        .stat-card .label { font-size: 0.9rem; opacity: 0.8; }

        /* BRAND HEADER */
        .brand-header { padding: 90px 20px; background: white; text-align: center; }
        .section-tag {
            color: #C9A962; font-weight: 700; letter-spacing: 3px;
            text-transform: uppercase; font-size: 0.8rem; margin-bottom: 16px;
        }
        .brand-header h2 {
            font-family: Georgia, serif; font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 900; color: #0A1929; margin-bottom: 20px;
        }
        .brand-header p { font-size: 1.15rem; color: #5A6C7D; line-height: 1.8; max-width: 700px; margin: 0 auto; }

        /* BRAND CARDS */
        .brands-grid {
            background: #F4F6F8; padding: 20px 40px 80px;
            display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px; max-width: 1400px; margin: 0 auto;
        }
        .brand-card {
            background: white; padding: 40px; border-radius: 12px;
            border: 2px solid transparent; transition: all 0.3s;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        }
        .brand-card:hover { border-color: #C9A962; transform: translateY(-6px); box-shadow: 0 20px 40px rgba(0,0,0,0.12); }
        .card-icon {
            width: 68px; height: 68px; background: #C9A962; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; margin-bottom: 24px;
        }
        .brand-card h3 {
            font-family: Georgia, serif; font-size: 1.6rem; font-weight: 700;
            color: #0A1929; margin-bottom: 14px;
        }
        .brand-card p { color: #5A6C7D; font-size: 1rem; line-height: 1.75; margin-bottom: 24px; }
        .features { list-style: none; padding: 0; margin-bottom: 28px; }
        .features li {
            padding: 7px 0; color: #2C3E50; display: flex;
            align-items: center; gap: 10px; font-size: 0.95rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .features li:last-child { border-bottom: none; }
        .features li::before { content: '✓'; color: #C9A962; font-weight: 900; flex-shrink: 0; }
        .card-link { color: #C9A962; font-weight: 700; text-decoration: none; font-size: 0.95rem; }
        .card-link:hover { text-decoration: underline; }

        /* CHI SIAMO */
        .chi-siamo {
            padding: 100px 40px;
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white;
        }
        .chi-siamo-inner {
            max-width: 1200px; margin: 0 auto;
            display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;
        }
        .chi-siamo h2 {
            font-family: Georgia, serif; font-size: clamp(2rem, 3.5vw, 3rem);
            font-weight: 900; margin-bottom: 30px;
        }
        .chi-siamo h2 span { color: #C9A962; }
        .chi-siamo p { font-size: 1.1rem; line-height: 1.9; margin-bottom: 20px; opacity: 0.9; }
        .valori-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .valore {
            padding: 28px; background: rgba(255,255,255,0.05);
            border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);
        }
        .valore h4 { font-size: 1.1rem; margin-bottom: 10px; color: #C9A962; font-weight: 700; }
        .valore p { font-size: 0.9rem; line-height: 1.65; opacity: 0.85; margin: 0; }

        /* CONSULENZA */
        .consulenza-section {
            padding: 100px 20px; background: #F4F6F8; text-align: center;
        }
        .consulenza-section .section-tag { margin-bottom: 16px; }
        .consulenza-section h2 {
            font-family: Georgia, serif; font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 900; color: #0A1929; margin-bottom: 20px;
        }
        .consulenza-section > p {
            font-size: 1.15rem; color: #5A6C7D; line-height: 1.8;
            max-width: 650px; margin: 0 auto 50px;
        }
        .consulenza-box {
            max-width: 760px; margin: 0 auto;
            background: white; border-radius: 16px;
            box-shadow: 0 8px 40px rgba(0,0,0,0.1);
            padding: 50px 50px;
            border-top: 4px solid #C9A962;
        }
        .consulenza-steps {
            display: grid; grid-template-columns: repeat(3,1fr); gap: 24px; margin-bottom: 40px;
        }
        .consulenza-step { text-align: center; }
        .step-num {
            width: 48px; height: 48px; background: #C9A962; color: white;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-weight: 900; font-size: 1.1rem; margin: 0 auto 14px;
        }
        .consulenza-step h4 { font-size: 1rem; font-weight: 700; color: #0A1929; margin-bottom: 6px; }
        .consulenza-step p { font-size: 0.9rem; color: #5A6C7D; line-height: 1.6; }
        .btn-calendar {
            display: inline-flex; align-items: center; gap: 12px;
            background: #C9A962; color: white; padding: 18px 48px;
            text-decoration: none; border-radius: 6px; font-weight: 700;
            font-size: 1.1rem; transition: all 0.2s;
        }
        .btn-calendar:hover { background: #b8934f; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(201,169,98,0.35); }
        .consulenza-note { margin-top: 18px; font-size: 0.85rem; color: #8A9BAC; }

        /* CTA */
        .cta-section { padding: 100px 20px; background: white; text-align: center; }
        .cta-section h2 {
            font-family: Georgia, serif; font-size: clamp(2rem, 4vw, 3.5rem);
            font-weight: 900; color: #0A1929; margin-bottom: 20px;
        }
        .cta-section p { font-size: 1.2rem; color: #5A6C7D; margin-bottom: 40px; max-width: 600px; margin-left: auto; margin-right: auto; }
        .cta-btns { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
        .btn-dark {
            background: #0A1929; color: white; padding: 16px 40px;
            text-decoration: none; border-radius: 4px; font-weight: 700; font-size: 1rem;
            border: 2px solid #0A1929; transition: all 0.2s;
        }
        .btn-dark:hover { background: transparent; color: #0A1929; }

        /* FOOTER */
        footer { background: #0A1929; color: rgba(255,255,255,0.75); padding: 70px 40px 30px; }
        .footer-grid {
            max-width: 1300px; margin: 0 auto;
            display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; margin-bottom: 50px;
        }
        .footer-brand h3 {
            font-family: Georgia, serif; font-size: 1.8rem; color: white; margin-bottom: 16px;
        }
        .footer-brand h3 span { color: #C9A962; }
        .footer-brand p { line-height: 1.8; margin-bottom: 20px; }
        .footer-brand address { font-style: normal; line-height: 1.8; font-size: 0.9rem; }
        .footer-col h4 { color: white; font-weight: 700; margin-bottom: 20px; font-size: 1rem; letter-spacing: 0.5px; }
        .footer-col ul { list-style: none; padding: 0; }
        .footer-col ul li { margin-bottom: 12px; }
        .footer-col ul li a { color: rgba(255,255,255,0.65); text-decoration: none; font-size: 0.9rem; transition: color 0.2s; }
        .footer-col ul li a:hover { color: #C9A962; }
        .footer-col ul li span { font-size: 0.9rem; }
        .footer-bottom {
            text-align: center; padding-top: 30px;
            border-top: 1px solid rgba(255,255,255,0.1);
            font-size: 0.85rem; color: rgba(255,255,255,0.4);
        }
        .footer-bottom a { color: rgba(255,255,255,0.4); text-decoration: none; }
        .footer-bottom a:hover { color: #C9A962; }

        /* HAMBURGER */
        .hamburger {
            display: none; flex-direction: column; gap: 5px;
            background: none; border: none; cursor: pointer; padding: 4px;
        }
        .hamburger span {
            display: block; width: 24px; height: 2px; background: white;
            border-radius: 2px; transition: all 0.3s;
        }
        .hamburger.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .hamburger.open span:nth-child(2) { opacity: 0; }
        .hamburger.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

        /* MOBILE NAV OVERLAY */
        .mobile-nav {
            display: none; position: fixed; top: 70px; left: 0; right: 0; bottom: 0;
            background: rgba(10, 25, 41, 0.98); z-index: 99;
            flex-direction: column; align-items: center; justify-content: center; gap: 32px;
        }
        .mobile-nav.open { display: flex; }
        .mobile-nav a {
            color: white; text-decoration: none; font-size: 1.5rem;
            font-weight: 600; letter-spacing: 1px; transition: color 0.2s;
        }
        .mobile-nav a:hover { color: #C9A962; }
        .mobile-nav .nav-cta { font-size: 1.1rem; }

        /* ACTIVE NAV LINK */
        .nav-links a.active { color: #C9A962; }

        /* BACK TO TOP */
        .back-to-top {
            position: fixed; bottom: 30px; right: 30px; z-index: 200;
            width: 48px; height: 48px; background: #C9A962; color: white;
            border: none; border-radius: 50%; cursor: pointer;
            font-size: 1.2rem; display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 16px rgba(201,169,98,0.4);
            opacity: 0; pointer-events: none; transition: opacity 0.3s, transform 0.3s;
            transform: translateY(10px);
        }
        .back-to-top.visible { opacity: 1; pointer-events: auto; transform: translateY(0); }
        .back-to-top:hover { background: #b8934f; }

        /* SCROLL ANIMATIONS */
        .fade-in {
            opacity: 0; transform: translateY(30px);
            transition: opacity 0.6s ease, transform 0.6s ease;
        }
        .fade-in.visible { opacity: 1; transform: translateY(0); }
        .fade-in-delay-1 { transition-delay: 0.1s; }
        .fade-in-delay-2 { transition-delay: 0.2s; }
        .fade-in-delay-3 { transition-delay: 0.3s; }

        /* RESPONSIVE */
        @media (max-width: 768px) {
            nav { padding: 0 20px; }
            .nav-links { display: none; }
            .hamburger { display: flex; }
            .hero-stats { grid-template-columns: 1fr; max-width: 300px; }
            .brands-grid { padding: 20px 20px 60px; }
            .chi-siamo { padding: 70px 20px; }
            .chi-siamo-inner { grid-template-columns: 1fr; gap: 40px; }
            .footer-grid { grid-template-columns: 1fr 1fr; }
            footer { padding: 60px 20px 30px; }
            .consulenza-steps { grid-template-columns: 1fr; gap: 28px; }
            .consulenza-box { padding: 36px 24px; }
            .back-to-top { bottom: 20px; right: 20px; }
        }
        @media (max-width: 480px) {
            .footer-grid { grid-template-columns: 1fr; }
            .valori-grid { grid-template-columns: 1fr; }
            nav .nav-cta { display: none; }
        }
    
</style>

<!-- HERO -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-badge fade-in">Real Estate · Finance · Construction</div>
        <h1 class="fade-in fade-in-delay-1">
            Il Partner Strategico per i Tuoi
            <span>Investimenti Immobiliari</span>
        </h1>
        <p class="fade-in fade-in-delay-2">
            BBRE Group integra expertise immobiliare, finanziaria ed edile per offrire soluzioni complete.
            Dalla ricerca dell'investimento alla ristrutturazione, dal finanziamento alla gestione patrimoniale.
        </p>
        <div class="hero-btns fade-in fade-in-delay-3">
            <a href="#brands" class="btn-primary">Scopri i Nostri Servizi</a>
            <a href="#consulenza" class="btn-outline">Prenota Consulenza Gratuita</a>
        </div>
        <div class="hero-stats">
            <div class="stat-card fade-in fade-in-delay-1">
                <div class="num">200+</div>
                <div class="label">Progetti Completati</div>
            </div>
            <div class="stat-card fade-in fade-in-delay-2">
                <div class="num">€50M+</div>
                <div class="label">Valore Gestito</div>
            </div>
            <div class="stat-card fade-in fade-in-delay-3">
                <div class="num">15+</div>
                <div class="label">Anni di Esperienza</div>
            </div>
        </div>
    </div>
</section>

<!-- BRAND HEADER -->
<section class="brand-header" id="brands">
    <div class="section-tag">I Nostri Brand</div>
    <h2>Quattro Divisioni, Un Unico Obiettivo</h2>
    <p>Ogni brand BBRE è specializzato in un'area specifica, ma tutti lavorano in sinergia per offrirti un servizio completo e integrato.</p>
</section>

<!-- BRAND CARDS -->
<div style="background: #F4F6F8; padding-bottom: 80px;">
    <div class="brands-grid">

        <div class="brand-card fade-in">
            <div class="card-icon">🏢</div>
            <h3>BBRE Immobiliare</h3>
            <p>Investimenti immobiliari strategici, acquisizione di immobili da valorizzare, sviluppo di progetti residenziali e commerciali su Milano e provincia.</p>
            <ul class="features">
                <li>Ricerca opportunità immobiliari</li>
                <li>Due diligence urbanistica e legale</li>
                <li>Valutazione ROI e business plan</li>
                <li>Gestione aste giudiziarie</li>
                <li>Compravendita immobiliare</li>
            </ul>
            <a href="<?php echo home_url('/immobiliare/'); ?>" class="card-link">Scopri di più →</a>
        </div>

        <div class="brand-card fade-in fade-in-delay-1">
            <div class="card-icon">💰</div>
            <h3>BBRE Finance</h3>
            <p>Soluzioni finanziarie personalizzate: mutui, leasing, prestiti e finanziamenti per privati, investitori e aziende.</p>
            <ul class="features">
                <li>Mutui prima casa e investimento</li>
                <li>Leasing immobiliare e strumentale</li>
                <li>Prestiti personali e aziendali</li>
                <li>Surroga e ristrutturazione mutui</li>
                <li>Consulenza finanziaria strategica</li>
            </ul>
            <a href="<?php echo home_url('/finance/'); ?>" class="card-link">Scopri di più →</a>
        </div>

        <div class="brand-card fade-in fade-in-delay-2">
            <div class="card-icon">🔨</div>
            <h3>BBRE Opere Edili</h3>
            <p>Ristrutturazioni complete, nuove costruzioni, riqualificazioni energetiche con gestione chiavi in mano del progetto.</p>
            <ul class="features">
                <li>Ristrutturazioni residenziali</li>
                <li>Frazionamenti e ampliamenti</li>
                <li>Efficientamento energetico</li>
                <li>Design e progettazione architettonica</li>
                <li>Gestione pratiche edilizie</li>
            </ul>
            <a href="<?php echo home_url('/opere-edili/'); ?>" class="card-link">Scopri di più →</a>
        </div>

        <div class="brand-card fade-in fade-in-delay-3">
            <div class="card-icon">📊</div>
            <h3>BBRE Consulenza Credito</h3>
            <p>Gestione del credito aziendale e privato, pianificazione finanziaria, ristrutturazione del debito e ottimizzazione fiscale.</p>
            <ul class="features">
                <li>Analisi e gestione del credito</li>
                <li>Ristrutturazione posizioni debitorie</li>
                <li>Pianificazione patrimoniale</li>
                <li>Ottimizzazione fiscale immobiliare</li>
                <li>Consulenza creditizia strategica</li>
            </ul>
            <a href="<?php echo home_url('/consulenza-credito/'); ?>" class="card-link">Scopri di più →</a>
        </div>

    </div>
</div>

<!-- CHI SIAMO -->
<section class="chi-siamo" id="chi-siamo">
    <div class="chi-siamo-inner">
        <div>
            <h2>Chi <span>Siamo</span></h2>
            <p>BBRE Group nasce dall'esperienza consolidata nel settore immobiliare, finanziario ed edilizio, con l'obiettivo di offrire un servizio integrato e completo ai propri clienti.</p>
            <p>La nostra forza risiede nella capacità di gestire ogni fase del processo: dall'individuazione dell'opportunità immobiliare, al finanziamento, alla realizzazione dei lavori, fino alla gestione e alla vendita finale.</p>
            <p>Operiamo principalmente su Milano e provincia, con un team di professionisti specializzati in ogni area di competenza: ingegneri, architetti, commercialisti, consulenti finanziari e legali.</p>
        </div>
        <div class="valori-grid">
            <div class="valore">
                <h4>Esperienza</h4>
                <p>Oltre 15 anni di operazioni immobiliari, edili e finanziarie con risultati certificati.</p>
            </div>
            <div class="valore">
                <h4>Trasparenza</h4>
                <p>Ogni operazione è documentata, ogni valutazione è certificata, ogni promessa è mantenuta.</p>
            </div>
            <div class="valore">
                <h4>Integrazione</h4>
                <p>Un unico interlocutore per tutte le tue esigenze: immobiliari, finanziarie ed edili.</p>
            </div>
            <div class="valore">
                <h4>Risultati</h4>
                <p>Focus sul ROI concreto: ogni progetto è studiato per massimizzare il ritorno sull'investimento.</p>
            </div>
        </div>
    </div>
</section>

<!-- CONSULENZA GRATUITA -->
<section class="consulenza-section" id="consulenza">
    <div class="section-tag">Prenota Online</div>
    <h2>Consulenza Gratuita con un Esperto</h2>
    <p>Scegli il giorno e l'orario che preferisci. In 30 minuti analizziamo la tua situazione e ti indichiamo il percorso migliore.</p>
    <div class="consulenza-box">
        <div class="consulenza-steps">
            <div class="consulenza-step">
                <div class="step-num">1</div>
                <h4>Scegli la Data</h4>
                <p>Seleziona giorno e orario disponibile nel calendario online.</p>
            </div>
            <div class="consulenza-step">
                <div class="step-num">2</div>
                <h4>Colloquio con l'Esperto</h4>
                <p>30 minuti di consulenza personalizzata con un professionista BBRE.</p>
            </div>
            <div class="consulenza-step">
                <div class="step-num">3</div>
                <h4>Piano d'Azione</h4>
                <p>Ricevi una roadmap concreta e senza impegno per il tuo progetto.</p>
            </div>
        </div>
        <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-calendar">
            📅 Prenota la Tua Consulenza Gratuita
        </a>
        <p class="consulenza-note">Nessun impegno • 100% gratuita • Risposta entro 24h</p>
    </div>
</section>

<!-- CTA FINALE -->
<section class="cta-section" id="contatti">
    <h2>Inizia il Tuo Progetto</h2>
    <p>Che tu sia un investitore, un proprietario immobiliare o un privato, BBRE Group ha la soluzione giusta per te.</p>
    <div class="cta-btns">
        <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-primary">Prenota Consulenza Gratuita</a>
        <a href="tel:+393358083125" class="btn-dark">Chiamaci Ora</a>
    </div>
</section>

<!-- FOOTER -->

<?php get_footer(); ?>
