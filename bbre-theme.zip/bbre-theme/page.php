<?php get_header(); ?>
<div style="padding: 120px 20px 80px; max-width: 900px; margin: 0 auto; min-height: 60vh;">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <h1 style="font-family: Georgia, serif; color: #0A1929; margin-bottom: 24px; font-size: 2rem;"><?php the_title(); ?></h1>
        <div style="line-height: 1.8; color: #444;"><?php the_content(); ?></div>
    <?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
