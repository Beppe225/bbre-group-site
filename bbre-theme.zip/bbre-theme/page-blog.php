<?php
/*
 * Template Name: BBRE Blog
 */
get_header();
?>

<style>
        .hero { background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%); color: white; padding: 130px 20px 70px; text-align: center; position: relative; overflow: hidden; }
        .hero::before { content: ''; position: absolute; top: -50%; right: -20%; width: 80%; height: 150%; background: radial-gradient(circle, rgba(201,169,98,0.10) 0%, transparent 70%); }
        .hero-inner { position: relative; z-index: 2; max-width: 800px; margin: 0 auto; }
        .hero-badge { display: inline-block; background: rgba(201,169,98,0.15); color: #C9A962; border: 1px solid rgba(201,169,98,0.4); padding: 8px 20px; border-radius: 50px; font-size: 0.8rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 24px; }
        .hero h1 { font-family: Georgia, serif; font-size: clamp(2rem, 4vw, 3rem); font-weight: 900; margin-bottom: 18px; line-height: 1.15; }
        .hero h1 span { color: #C9A962; }
        .hero p { font-size: 1.1rem; opacity: 0.85; line-height: 1.8; max-width: 600px; margin: 0 auto; }
        .filters-bar { background: white; padding: 30px 40px; border-bottom: 1px solid #eee; position: sticky; top: 70px; z-index: 50; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }
        .filters-inner { max-width: 1200px; margin: 0 auto; display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
        .filter-label { font-size: 0.85rem; font-weight: 600; color: #8A9BAC; text-transform: uppercase; letter-spacing: 1px; margin-right: 8px; }
        .filter-btn { padding: 8px 20px; border-radius: 50px; border: 2px solid #E0E0E0; background: white; color: #5A6C7D; font-size: 0.88rem; font-weight: 600; cursor: pointer; transition: all 0.2s; font-family: inherit; }
        .filter-btn:hover { border-color: #C9A962; color: #C9A962; }
        .filter-btn.active { background: #C9A962; border-color: #C9A962; color: white; }
        .blog-section { background: #F4F6F8; padding: 60px 40px 90px; }
        .blog-inner { max-width: 1200px; margin: 0 auto; }
        .blog-count { font-size: 0.9rem; color: #8A9BAC; margin-bottom: 30px; }
        .blog-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 28px; }
        .article-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.07); transition: all 0.3s; display: flex; flex-direction: column; }
        .article-card:hover { transform: translateY(-5px); box-shadow: 0 16px 40px rgba(0,0,0,0.12); }
        .article-card.hidden { display: none; }
        .card-thumb { height: 12px; background: #C9A962; }
        .card-body { padding: 28px; flex: 1; display: flex; flex-direction: column; }
        .card-meta { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
        .card-cat { font-size: 0.75rem; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; padding: 4px 12px; border-radius: 20px; background: rgba(201,169,98,0.12); color: #b8934f; }
        .card-date { font-size: 0.82rem; color: #8A9BAC; }
        .card-body h2 { font-family: Georgia, serif; font-size: 1.2rem; font-weight: 700; color: #0A1929; margin-bottom: 12px; line-height: 1.4; }
        .card-body p { font-size: 0.93rem; color: #5A6C7D; line-height: 1.75; flex: 1; margin-bottom: 20px; }
        .card-footer { display: flex; align-items: center; justify-content: space-between; padding-top: 16px; border-top: 1px solid #f0f0f0; }
        .card-author { font-size: 0.82rem; color: #8A9BAC; }
        .card-link { color: #C9A962; font-weight: 700; text-decoration: none; font-size: 0.88rem; }
        .card-link:hover { text-decoration: underline; }
        .no-results { text-align: center; padding: 60px 20px; display: none; }
        .no-results h3 { font-family: Georgia, serif; font-size: 1.5rem; color: #0A1929; margin-bottom: 10px; }
        .cta-section { padding: 90px 20px; background: white; text-align: center; }
        .cta-box { max-width: 680px; margin: 0 auto; background: #F4F6F8; border-radius: 16px; padding: 50px; border-top: 4px solid #C9A962; }
        .cta-box h3 { font-family: Georgia, serif; font-size: 1.9rem; font-weight: 900; color: #0A1929; margin-bottom: 14px; }
        .cta-box p { color: #5A6C7D; font-size: 1.05rem; margin-bottom: 28px; line-height: 1.75; }
        .btn-calendar { display: inline-flex; align-items: center; gap: 10px; background: #C9A962; color: white; padding: 15px 40px; text-decoration: none; border-radius: 6px; font-weight: 700; font-size: 1rem; transition: all 0.2s; }
        .btn-calendar:hover { background: #b8934f; transform: translateY(-2px); }
        @media (max-width: 768px) { .filters-bar { padding: 20px; } .blog-section { padding: 40px 20px 70px; } .blog-grid { grid-template-columns: 1fr; } .cta-box { padding: 36px 24px; } }
</style>

<div class="hero">
    <div class="hero-inner">
        <div class="hero-badge">Knowledge Hub</div>
        <h1>Blog <span>BBRE Group</span></h1>
        <p>Guide pratiche, analisi di mercato e strategie di investimento immobiliare per prendere decisioni informate.</p>
    </div>
</div>

<?php $categories = get_categories(['hide_empty' => true]); ?>

<div class="filters-bar">
    <div class="filters-inner">
        <span class="filter-label">Filtra:</span>
        <button class="filter-btn active" data-filter="all">Tutti</button>
        <?php foreach ($categories as $cat) : ?>
        <button class="filter-btn" data-filter="<?php echo esc_attr($cat->slug); ?>"><?php echo esc_html($cat->name); ?></button>
        <?php endforeach; ?>
    </div>
</div>

<section class="blog-section">
    <div class="blog-inner">
        <?php
        $args = ['post_type' => 'post', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'DESC'];
        $query = new WP_Query($args);
        $total = $query->found_posts;
        ?>
        <p class="blog-count" id="blogCount">Mostrando <strong><?php echo $total; ?></strong> articoli</p>
        <div class="blog-grid" id="blogGrid">
        <?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
            $cats = get_the_category();
            $cat_slug = $cats ? $cats[0]->slug : '';
            $cat_name = $cats ? $cats[0]->name : '';
            $excerpt = has_excerpt() ? get_the_excerpt() : wp_trim_words(get_the_content(), 22, '...');
        ?>
            <article class="article-card" data-category="<?php echo esc_attr($cat_slug); ?>">
                <div class="card-thumb"></div>
                <div class="card-body">
                    <div class="card-meta">
                        <?php if ($cat_name) : ?><span class="card-cat"><?php echo esc_html($cat_name); ?></span><?php endif; ?>
                        <span class="card-date"><?php echo get_the_date('d M Y'); ?></span>
                    </div>
                    <h2><?php the_title(); ?></h2>
                    <p><?php echo esc_html($excerpt); ?></p>
                    <div class="card-footer">
                        <span class="card-author">✍️ <?php the_author(); ?></span>
                        <a href="<?php the_permalink(); ?>" class="card-link">Leggi →</a>
                    </div>
                </div>
            </article>
        <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
        <div class="no-results" id="noResults"><h3>Nessun articolo trovato</h3><p>Prova un'altra categoria.</p></div>
    </div>
</section>

<section class="cta-section">
    <div class="cta-box fade-in">
        <h3>Vuoi una Consulenza Personalizzata?</h3>
        <p>I nostri esperti sono pronti ad analizzare la tua situazione specifica e guidarti nelle decisioni più importanti.</p>
        <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-calendar">📅 Prenota Consulenza Gratuita</a>
    </div>
</section>

<script>
(function() {
    var btns = document.querySelectorAll('.filter-btn');
    var cards = document.querySelectorAll('.article-card');
    var countEl = document.getElementById('blogCount');
    var noResults = document.getElementById('noResults');
    btns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            btns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            var filter = btn.dataset.filter;
            var visible = 0;
            cards.forEach(function(card) {
                var show = filter === 'all' || card.dataset.category === filter;
                card.classList.toggle('hidden', !show);
                if (show) visible++;
            });
            countEl.innerHTML = 'Mostrando <strong>' + visible + '</strong> articoli';
            noResults.style.display = visible === 0 ? 'block' : 'none';
        });
    });
})();
</script>

<?php get_footer(); ?>
