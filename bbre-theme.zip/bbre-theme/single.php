<?php get_header(); ?>

<style>
        /* ARTICLE HERO */
        .article-hero {
            background: linear-gradient(135deg, #0A1929 0%, #1a2f42 100%);
            color: white; padding: 130px 20px 70px; text-align: center;
            position: relative; overflow: hidden;
        }
        .article-hero::before {
            content: ''; position: absolute; top: -50%; right: -20%;
            width: 80%; height: 150%;
            background: radial-gradient(circle, rgba(201,169,98,0.10) 0%, transparent 70%);
        }
        .article-hero-inner { position: relative; z-index: 2; max-width: 860px; margin: 0 auto; }
        .breadcrumb { display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; }
        .breadcrumb a { color: rgba(255,255,255,0.6); text-decoration: none; font-size: 0.85rem; }
        .breadcrumb a:hover { color: #C9A962; }
        .breadcrumb span { color: rgba(255,255,255,0.4); font-size: 0.85rem; }
        .article-cat {
            display: inline-block; background: rgba(201,169,98,0.15); color: #C9A962;
            border: 1px solid rgba(201,169,98,0.4); padding: 6px 18px; border-radius: 50px;
            font-size: 0.78rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase;
            margin-bottom: 20px;
        }
        .article-hero h1 { font-family: Georgia, serif; font-size: clamp(1.8rem, 4vw, 2.8rem); font-weight: 900; line-height: 1.2; margin-bottom: 20px; }
        .article-meta { display: flex; align-items: center; justify-content: center; gap: 20px; flex-wrap: wrap; opacity: 0.8; font-size: 0.9rem; }
        .article-meta span { display: flex; align-items: center; gap: 6px; }

        /* ARTICLE LAYOUT */
        .article-layout { max-width: 1100px; margin: 0 auto; padding: 70px 40px; display: grid; grid-template-columns: 1fr 300px; gap: 60px; align-items: start; }

        /* ARTICLE BODY */
        .article-body { min-width: 0; }
        .article-body .lead { font-size: 1.2rem; line-height: 1.9; color: #3D4F5C; border-left: 4px solid #C9A962; padding-left: 20px; margin-bottom: 40px; }
        .article-body h2 { font-family: Georgia, serif; font-size: 1.6rem; font-weight: 700; color: #0A1929; margin: 40px 0 16px; }
        .article-body h3 { font-family: Georgia, serif; font-size: 1.2rem; font-weight: 700; color: #0A1929; margin: 28px 0 12px; }
        .article-body p { font-size: 1.02rem; line-height: 1.9; color: #3D4F5C; margin-bottom: 20px; }
        .article-body ul, .article-body ol { padding-left: 24px; margin-bottom: 20px; }
        .article-body li { font-size: 1.02rem; line-height: 1.85; color: #3D4F5C; margin-bottom: 8px; }
        .article-body strong { color: #0A1929; font-weight: 700; }
        .info-box { background: #F4F6F8; border-left: 4px solid #C9A962; padding: 24px 28px; border-radius: 0 8px 8px 0; margin: 32px 0; }
        .info-box h4 { font-weight: 700; color: #0A1929; margin-bottom: 10px; font-size: 1rem; }
        .info-box p { font-size: 0.95rem; color: #5A6C7D; margin: 0; line-height: 1.75; }
        .warning-box { background: #FFF8E7; border-left: 4px solid #F0A500; padding: 24px 28px; border-radius: 0 8px 8px 0; margin: 32px 0; }
        .warning-box h4 { font-weight: 700; color: #7A5200; margin-bottom: 10px; font-size: 1rem; }
        .warning-box p { font-size: 0.95rem; color: #5A4000; margin: 0; line-height: 1.75; }

        /* SIDEBAR */
        .sidebar { position: sticky; top: 100px; }
        .sidebar-box { background: #F4F6F8; border-radius: 12px; padding: 28px; margin-bottom: 24px; border-top: 3px solid #C9A962; }
        .sidebar-box h4 { font-family: Georgia, serif; font-size: 1.05rem; font-weight: 700; color: #0A1929; margin-bottom: 16px; }
        .sidebar-box p { font-size: 0.9rem; color: #5A6C7D; line-height: 1.7; margin-bottom: 16px; }
        .btn-sidebar { display: block; background: #C9A962; color: white; padding: 12px 20px; border-radius: 6px; font-weight: 700; font-size: 0.9rem; text-decoration: none; text-align: center; transition: background 0.2s; }
        .btn-sidebar:hover { background: #b8934f; }
        .related-list { list-style: none; padding: 0; }
        .related-list li { border-bottom: 1px solid #E8ECF0; padding: 10px 0; }
        .related-list li:last-child { border-bottom: none; }
        .related-list a { color: #2C3E50; text-decoration: none; font-size: 0.9rem; line-height: 1.5; font-weight: 500; transition: color 0.2s; }
        .related-list a:hover { color: #C9A962; }

        .back-to-blog { padding: 30px 40px 60px; max-width: 1100px; margin: 0 auto; }
        .back-link { color: #C9A962; text-decoration: none; font-weight: 700; font-size: 0.95rem; }
        .back-link:hover { text-decoration: underline; }

        @media (max-width: 900px) {
            .article-layout { grid-template-columns: 1fr; padding: 50px 20px; }
            .sidebar { position: static; }
        }
        @media (max-width: 768px) {
            .back-to-blog { padding-left: 20px; padding-right: 20px; }
        }
</style>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<div class="article-hero">
    <div class="article-hero-inner">
        <div class="breadcrumb">
            <a href="<?php echo home_url('/'); ?>">Home</a>
            <span>›</span>
            <a href="<?php echo home_url('/blog/'); ?>">Blog</a>
            <span>›</span>
            <span><?php the_title(); ?></span>
        </div>
        <?php
        $categories = get_the_category();
        if ( $categories ) {
            echo '<div class="article-cat">' . esc_html( $categories[0]->name ) . '</div>';
        }
        ?>
        <h1><?php the_title(); ?></h1>
        <div class="article-meta">
            <span>📅 <?php echo get_the_date('d F Y'); ?></span>
            <span>✍️ <?php the_author(); ?></span>
            <span>⏱ <?php
                $content = get_the_content();
                $word_count = str_word_count( strip_tags( $content ) );
                $minutes = max(1, round( $word_count / 200 ));
                echo $minutes . ' min di lettura';
            ?></span>
        </div>
    </div>
</div>

<div class="article-layout">
    <div class="article-body">
        <?php the_content(); ?>
    </div>
    <aside class="sidebar">
        <div class="sidebar-box">
            <h4>Consulenza Gratuita</h4>
            <p>Hai domande su questo argomento? I nostri esperti sono a tua disposizione per una consulenza gratuita.</p>
            <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="btn-sidebar">Prenota Ora — È Gratuita</a>
        </div>
        <div class="sidebar-box">
            <h4>Articoli Correlati</h4>
            <?php
            $related = new WP_Query([
                'post_type' => 'post',
                'posts_per_page' => 4,
                'post__not_in' => [ get_the_ID() ],
                'category__in' => wp_get_post_categories( get_the_ID() ),
                'orderby' => 'rand',
            ]);
            if ( $related->have_posts() ) : ?>
            <ul class="related-list">
                <?php while ( $related->have_posts() ) : $related->the_post(); ?>
                <li>
                    <?php $cats = get_the_category(); if ($cats) echo '<span class="related-cat">' . esc_html($cats[0]->name) . '</span>'; ?>
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </li>
                <?php endwhile; wp_reset_postdata(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </aside>
</div>

<div class="back-to-blog">
    <a href="<?php echo home_url('/blog/'); ?>" class="back-link">← Torna al Blog</a>
</div>

<?php endwhile; endif; ?>

<?php get_footer(); ?>
