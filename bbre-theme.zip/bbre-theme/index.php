<?php get_header(); ?>
<div style="padding: 120px 20px 80px; text-align: center; min-height: 60vh;">
    <h1 style="font-family: Georgia, serif; color: #0A1929; margin-bottom: 20px;"><?php the_title(); ?></h1>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div><?php the_content(); ?></div>
    <?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
