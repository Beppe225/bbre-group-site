<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav class="bbre-nav" id="bbrenav">
    <a href="<?php echo home_url('/'); ?>" class="nav-logo">BBRE <span>Group</span></a>
    <ul class="nav-links">
        <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
        <li><a href="<?php echo home_url('/immobiliare/'); ?>">Immobiliare</a></li>
        <li><a href="<?php echo home_url('/finance/'); ?>">Finance</a></li>
        <li><a href="<?php echo home_url('/opere-edili/'); ?>">Opere Edili</a></li>
        <li><a href="<?php echo home_url('/consulenza-credito/'); ?>">Consulenza Credito</a></li>
        <li><a href="<?php echo home_url('/blog/'); ?>">Blog</a></li>
        <li><a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="nav-cta">Prenota Consulenza</a></li>
    </ul>
    <button class="hamburger" id="hamburger" aria-label="Menu">
        <span></span><span></span><span></span>
    </button>
</nav>

<div class="mobile-nav" id="mobileNav">
    <a href="<?php echo home_url('/'); ?>" onclick="closeMobileNav()">Home</a>
    <a href="<?php echo home_url('/immobiliare/'); ?>" onclick="closeMobileNav()">Immobiliare</a>
    <a href="<?php echo home_url('/finance/'); ?>" onclick="closeMobileNav()">Finance</a>
    <a href="<?php echo home_url('/opere-edili/'); ?>" onclick="closeMobileNav()">Opere Edili</a>
    <a href="<?php echo home_url('/consulenza-credito/'); ?>" onclick="closeMobileNav()">Consulenza Credito</a>
    <a href="<?php echo home_url('/blog/'); ?>" onclick="closeMobileNav()">Blog</a>
    <a href="https://calendar.app.google/euJyxzVn7kpohk6e9" target="_blank" class="mobile-cta">Prenota Consulenza</a>
</div>
